import re
import string

def clean_text(s: str) -> str:
    if not isinstance(s, str):
        raise TypeError("clean_text: input must be a string")

    # 1) 소문자 + 1차 strip
    s = s.lower().strip()

    # 2) ASCII 문장부호 제거 ('와 -는 보존)
    keep = {"'", "-"}
    remove_chars = ''.join(ch for ch in string.punctuation if ch not in keep)
    s = re.sub(f"[{re.escape(remove_chars)}]", "", s)

    # 3) 단어 사이가 아닌 고아 '-'와 '\'' 제거
    s = re.sub(r"(?<!\w)-+(?!\w)", "", s)
    s = re.sub(r"(?<!\w)'+(?!\w)", "", s)

    # 4) 공백 압축 + strip  ←★ 이 줄이 꼭 필요!
    s = re.sub(r"\s+", " ", s)
    s = s.strip()

    return s




if __name__ == "__main__":
    def run_tests():
        assert clean_text("  Hello,   WORLD!  ") == "hello world"
        assert clean_text("\tROCK-'N'-ROLL!!") == "rock-'n'-roll"
        assert clean_text("...") == ""
        assert clean_text(" A  B\tC\nD ") == "a b c d"
        print("filters.py tests passed.")
    # run_tests()
    pass

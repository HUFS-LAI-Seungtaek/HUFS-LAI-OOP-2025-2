# dsops package root — re-export public API
from .split.train_test import train_test_split
from .stats.labels import label_distribution

__all__ = ["train_test_split", "label_distribution"]

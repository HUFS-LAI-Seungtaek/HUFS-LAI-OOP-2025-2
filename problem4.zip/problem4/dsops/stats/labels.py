def label_distribution(labels: list[str]) -> dict[str, int]:
    """Return a simple frequency dictionary for labels."""
    freq: dict[str, int] = {}
    for lb in labels:
        freq[lb] = freq.get(lb, 0) + 1
    return freq

"""
Problem 4 — dsops (dataset utilities: split & label stats)
"""

# 양쪽 실행 지원:
# - 패키지 실행: python -m dsops.main  → 상대 import 사용
# - 파일 직접 실행: python dsops/main.py → 부모 경로를 PYTHONPATH에 추가 후 절대 import
if __name__ == "__main__" and (__package__ is None or __package__ == ""):
    # 직접 실행 모드
    import os, sys
    here = os.path.abspath(os.path.dirname(__file__))      # .../dsops
    parent = os.path.dirname(here)                         # 프로젝트 루트
    if parent not in sys.path:
        sys.path.insert(0, parent)
    from dsops import train_test_split, label_distribution  # 절대 import
else:
    # 모듈 실행 모드 (-m)
    from . import train_test_split, label_distribution      # 상대 import


def run_demo():
    tr, te = train_test_split([1, 2, 3, 4, 5], 0.4, seed=42)
    print(tr, te)
    print(label_distribution(["cat", "dog", "cat"]))


if __name__ == "__main__":
    run_demo()
